public interface IDamageable
{
    void OnHealthChange(float delta);
}