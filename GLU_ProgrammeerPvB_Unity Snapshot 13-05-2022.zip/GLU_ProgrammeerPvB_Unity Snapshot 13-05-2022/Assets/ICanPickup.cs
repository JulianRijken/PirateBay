public interface ICanPickup
{
    void OnPickup(Effect effect);

    bool CanPickup();
}
